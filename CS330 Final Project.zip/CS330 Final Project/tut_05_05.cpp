//CS330 Module 7-1
//Final Project
//Christopher Clark
//August 14, 2022

#include <iostream>         
#include <cstdlib>         
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>      // image loading header file

//math
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <learnOpengl/camera.h> //camera utility header file

using namespace std;

#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

namespace
{
    const char* const WINDOW_TITLE = "Final Project"; //window frame title

    //window size
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    //struct for GL data
    struct GLMesh
    {
        //Handle for shapes VAO, VBO, and vetices
        GLuint planeVAO;
        GLuint planeVBO;
        GLuint nPlaneVertices;
        GLuint cndlCubeVAO;
        GLuint cndlCubeVBO;
        GLuint cndlCubeVertices;
        GLuint boxCubeVAO;
        GLuint boxCubeVBO;
        GLuint boxCubeVertices;
        GLuint candleVAO;
        GLuint candleVBO;
        GLuint candleVertices;
        GLuint vao;
        GLuint vbo;
        GLuint nVertices;

    };

    //primary window
    GLFWwindow* gWindow = nullptr;
    GLMesh gMesh;
    GLuint gTextureId;
    GLuint gTextureIDtable;
    GLuint gTextureIdcndlcube;
    GLuint gTextureIdboxcube;
    GLuint gTextureIdcandle;
    GLuint gTextureIdsphere;
    glm::vec2 gUVScale(5.0f, 5.0f);
    GLint gTexWrapMode = GL_REPEAT;
    GLuint gProgramId;
    GLuint gLampProgramId;

    //define camera
    Camera gCamera(glm::vec3(0.0f, 0.0f, 5.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    float angle = 0.0f;
    bool increaseAngle = true;
    bool ortho = false;

    //set up timing for frame
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh& mesh);
void UCreateTexturedMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


//shader code
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;
layout(location = 2) in vec2 textureCoordinate;

out vec2 vertexTextureCoordinate;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
    vertexTextureCoordinate = textureCoordinate;
}
);


//fragment shader
const GLchar* fragmentShaderSource = GLSL(440,
    in vec2 vertexTextureCoordinate;

out vec4 fragmentColor;

uniform sampler2D uTexture;
uniform sampler2D uTextureBase;
uniform sampler2D uTextureExtra;
uniform sampler2D multipleTextures;

void main()
{
    ////send data to GPU
    fragmentColor = texture(uTexture, vertexTextureCoordinate);

   }
);

//flip image to correct orientation
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    //gernate mesh
    UCreateMesh(gMesh);

    //start shader
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    //load texture from file
    const char* texFilename = "../../resources/textures/candle.jpg";
    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    texFilename = "../../resources/textures/WOOD.jpg";
    if (!UCreateTexture(texFilename, gTextureIDtable))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    texFilename = "../../resources/textures/candle.jpg";
    if (!UCreateTexture(texFilename, gTextureIdcndlcube))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    texFilename = "../../resources/textures/greenbox.jpg";
    if (!UCreateTexture(texFilename, gTextureIdboxcube))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    glUseProgram(gProgramId);
    glUniform1i(glGetUniformLocation(gProgramId, "uTexturePyramid"), 0);
    glUniform1i(glGetUniformLocation(gProgramId, "uTexturePlane"), 1);
    glUniform1i(glGetUniformLocation(gProgramId, "uTexturePyrmTop"), 2);
    glUniform1i(glGetUniformLocation(gProgramId, "uTextureWoodBox"), 3);
    //glUniform1i(glGetUniformLocation(gProgramId, "uTextureSphere"), 4);

    //clear background with black color
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    //while loop to code rendering
    while (!glfwWindowShouldClose(gWindow))
    {

        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        //input process
        UProcessInput(gWindow);

        //frame render
        URender();

        //monitor input events
        glfwPollEvents();
    }

    //remove data from mseh
    UDestroyMesh(gMesh);

    //remove texture from mesh
    UDestroyTexture(gTextureId);
    UDestroyTexture(gTextureIDtable);
    UDestroyTexture(gTextureIdcndlcube);
    UDestroyTexture(gTextureIdboxcube);
    //UDestroyTexture(gTextureIdsphere);

    //stop shader
    UDestroyShaderProgram(gProgramId);
    //UDestroyShaderProgram(gLampProgramId);

    exit(EXIT_SUCCESS);
}


//initialize glfw/glew
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{

    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    //build glfw window
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    //monitor/capture mouse movement
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    //initialize glew
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


//method to process inputs
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);

    //moves camera up and down
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);


    //changes from ortho to perspective camera
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) {
        ortho = true;
    }
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
        ortho = false;
    }

    //reset camera to default speed and setting
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
        gCamera = glm::vec3(0.0f, 0.0f, 5.0f);
        //cameraSpeed = 2.5f;

        if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS && gTexWrapMode != GL_REPEAT)
        {
            glBindTexture(GL_TEXTURE_2D, gTextureId);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            glBindTexture(GL_TEXTURE_2D, 0);
            gTexWrapMode = GL_REPEAT;
            cout << "Current Texture Wrapping Mode: REPEAT" << endl;
        }
        if (glfwGetKey(window, GLFW_KEY_RIGHT_BRACKET) == GLFW_PRESS)
        {
            gUVScale += 0.1f;
            cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" <<
                endl;
        }
        else if (glfwGetKey(window, GLFW_KEY_LEFT_BRACKET) == GLFW_PRESS)
        {
            gUVScale -= 0.1f;
            cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" <<
                endl;
        }
    }
}



//callback for window size change
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


//callback used when mouse movement detected
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos;

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


//callback for mouse scroll 
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

//callback fro mouse buttons
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }

}


//render frame
void URender()
{
    //z-depth
    glEnable(GL_DEPTH_TEST);

    //clear buffers and frame
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    ///////////////////////////////////////////candle holder main body pyramid.
    //object scale, rotation, translation, moden, view, and projection/perspective.
    glm::mat4 scale = glm::scale(glm::vec3(2.0f, 2.0f, 2.0f));
    glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(-1.0, 1.0f, 1.0f));
    glm::mat4 translation = glm::translate(glm::vec3(-2.2f, 0.0f, 0.5f));
    glm::mat4 model = translation * rotation * scale;
    glm::mat4 view = gCamera.GetViewMatrix();
    glm::mat4 projection = glm::ortho(-10.0f, 10.0f, -10.0f, 100.0f, -100.0f, 100.0f);

    if (!ortho) {
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    if (ortho) {
        projection = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, -10.0f, 10.0f);
    };

    //define whcih sader to be used
    glUseProgram(gProgramId);

    //send data to shader
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glBindVertexArray(gMesh.vao);

    //bind texture
    glBindTexture(GL_TEXTURE_2D, gTextureId);

    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);

    /////////////////////////////////////////table top plane
    glm::mat4 plscale = glm::scale(glm::vec3(2.0f, 2.0f, 2.0f));
    glm::mat4 plrotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
    glm::mat4 pltranslation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    glm::mat4 plmodel = pltranslation * plrotation * plscale;
    glm::mat4 plview = gCamera.GetViewMatrix();
    glm::mat4 plprojection = glm::ortho(-10.0f, 10.0f, -10.0f, 100.0f, -100.0f, 100.0f);

    if (!ortho) {
        plprojection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    if (ortho) {
        plprojection = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, -10.0f, 10.0f);
    };

    //define which sahder to be used
    glUseProgram(gProgramId);

    //send data to shader
    GLint plmodelLoc = glGetUniformLocation(gProgramId, "model");
    GLint plviewLoc = glGetUniformLocation(gProgramId, "view");
    GLint plprojLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(plmodelLoc, 1, GL_FALSE, glm::value_ptr(plmodel));
    glUniformMatrix4fv(plviewLoc, 1, GL_FALSE, glm::value_ptr(plview));
    glUniformMatrix4fv(plprojLoc, 1, GL_FALSE, glm::value_ptr(plprojection));

    //plane
    glBindVertexArray(gMesh.planeVAO);

    //bind texture
    //glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureIDtable);

    glDrawArrays(GL_TRIANGLES, 0, gMesh.nPlaneVertices);

    /////////////////////////////////////////candle top 
    glm::mat4 cbscale = glm::scale(glm::vec3(2.0f, 2.0f, 2.0f));
    glm::mat4 cbrotation = glm::rotate(0.0f, glm::vec3(-1.0, 1.0f, 0.0f));
    glm::mat4 cbtranslation = glm::translate(glm::vec3(-2.2f, 0.0f, 0.5f));
    glm::mat4 cbmodel = cbtranslation * cbrotation * cbscale;

    //camera setting
    glm::mat4 cbview = gCamera.GetViewMatrix();

    //perspective
    glm::mat4 cbprojection = glm::ortho(-10.0f, 10.0f, -10.0f, 100.0f, -100.0f, 100.0f);

    if (!ortho) {
        cbprojection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    if (ortho) {
        cbprojection = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, -10.0f, 10.0f);
    };

    //defeine whcih sader to be used
    glUseProgram(gProgramId);

    //send data to shader
    GLint cbmodelLoc = glGetUniformLocation(gProgramId, "model");
    GLint cbviewLoc = glGetUniformLocation(gProgramId, "view");
    GLint cbprojLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(cbmodelLoc, 1, GL_FALSE, glm::value_ptr(cbmodel));
    glUniformMatrix4fv(cbviewLoc, 1, GL_FALSE, glm::value_ptr(cbview));
    glUniformMatrix4fv(cbprojLoc, 1, GL_FALSE, glm::value_ptr(cbprojection));

    glBindVertexArray(gMesh.cndlCubeVAO);

    //bind texture
    //glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureIdcndlcube);

    glDrawArrays(GL_TRIANGLES, 0, gMesh.cndlCubeVertices);

    /////////////////////////////////////////wooden box 
    glm::mat4 bxscale = glm::scale(glm::vec3(1.0f, 0.5f, 1.0f));
    glm::mat4 bxrotation = glm::rotate(0.0f, glm::vec3(-1.0, 1.0f, 0.0f));
    glm::mat4 bxtranslation = glm::translate(glm::vec3(0.0f, -0.75f, 0.5f));
    glm::mat4 bxmodel = bxtranslation * bxrotation * bxscale;

    //camera setting
    glm::mat4 bxview = gCamera.GetViewMatrix();

    //perspective
    glm::mat4 bxprojection = glm::ortho(-10.0f, 10.0f, -10.0f, 100.0f, -100.0f, 100.0f);

    if (!ortho) {
        bxprojection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    if (ortho) {
        bxprojection = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, -10.0f, 10.0f);
    };

    //defeine whcih sader to be used
    glUseProgram(gProgramId);

    //send data to shader
    GLint bxmodelLoc = glGetUniformLocation(gProgramId, "model");
    GLint bxviewLoc = glGetUniformLocation(gProgramId, "view");
    GLint bxprojLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(bxmodelLoc, 1, GL_FALSE, glm::value_ptr(bxmodel));
    glUniformMatrix4fv(bxviewLoc, 1, GL_FALSE, glm::value_ptr(bxview));
    glUniformMatrix4fv(bxprojLoc, 1, GL_FALSE, glm::value_ptr(bxprojection));

    glBindVertexArray(gMesh.boxCubeVAO);

    //bind texture
    glBindTexture(GL_TEXTURE_2D, gTextureIdboxcube);

    glDrawArrays(GL_TRIANGLES, 0, gMesh.boxCubeVertices);

    //shut down VAO
    glBindVertexArray(0);
    //glUseProgram(0);

    //poll IO and swap buffers
    glfwSwapBuffers(gWindow);

}

void UCreateMesh(GLMesh& mesh)
{

    GLfloat verts[] = {

        //candle holder main body
        //verts                //normals
       -0.25f, -0.5f, -0.25f,   0.0f, 0.0f, // Top Right Vertex 0
        0.25f, -0.5f, -0.25f,   1.0f, 0.0f, // Bottom Right Vertex 1
        0.0f,   0.5f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

       -0.25f, -0.5f,  0.25f,   0.0f, 0.0f, // Top Right Vertex 0
        0.25f, -0.5f,  0.25f,   1.0f, 0.0f, // Bottom Right Vertex 1
        0.0f,   0.5f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

       -0.25f, -0.5f, -0.25f,   0.0f, 1.0f, // Top Right Vertex 0
       -0.25f, -0.5f,  0.0f,    0.0f, 0.0f, // Bottom Right Vertex 1
        0.0f,   0.5f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

        0.25f, -0.5f, -0.25f,   0.0f, 1.0f, // Top Right Vertex 0
        0.25f, -0.5f,  0.25f,   0.0f, 0.0f, // Bottom Right Vertex 1
        0.0f,   0.5f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

        0.25f, -0.5f, -0.25f,   1.0f, 1.0f, // Top Right Vertex 0
        0.25f, -0.5f,  0.25f,   1.0f, 0.0f, // Bottom Right Vertex 1
        0.0f,   0.5f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

       -0.25f, -0.5f,  0.25f,   0.0f, 0.0f, // Top Right Vertex 0
       -0.25f, -0.5f, -0.25f,   0.0f, 1.0f, // Bottom Right Vertex 1
        0.0f,   0.5f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

    };

    GLfloat planeVerts[] = {

        //table top
        //verts                //normals
        -3.0f,  -0.5f, -3.0f,    0.0f, 0.0f,
         3.0f,  -0.5f, -3.0f,    1.0f, 0.0f,
         3.0f,  -0.5f,  3.0f,    1.0f, 1.0f,
         3.0f,  -0.5f,  3.0f,    1.0f, 1.0f,
        -3.0f,  -0.5f,  3.0f,    0.0f, 1.0f,
        -3.0f,  -0.5f, -3.0f,    0.0f, 0.0f

    };

    GLfloat cndlCubeVerts[] = {

        //candle holder top
        //verts                 //normals
        0.15f,  0.5f,  0.15f,   0.0f, 0.0f, // Top Right Vertex 0
       -0.15f,  0.5f,  0.15f,   1.0f, 0.0f, // Bottom Right Vertex 1
        0.0f,  -0.2f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

        0.15f,  0.5f, -0.15f,   0.0f, 0.0f, // Top Right Vertex 0
       -0.15f,  0.5f, -0.15f,   1.0f, 0.0f, // Bottom Right Vertex 1
        0.0f,  -0.2f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

        0.15f,  0.5f,  0.15f,   0.0f, 1.0f, // Top Right Vertex 0
        0.15f,  0.5f, -0.15f,   0.0f, 0.0f, // Bottom Right Vertex 1
        0.0f,  -0.2f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

       -0.15f,  0.5f,  0.15f,   0.0f, 1.0f, // Top Right Vertex 0
       -0.15f,  0.5f, -0.15f,   0.0f, 0.0f, // Bottom Right Vertex 1
        0.0f,  -0.2f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

       -0.15f,  0.5f,  0.15f,   1.0f, 1.0f, // Top Right Vertex 0
       -0.15f,  0.5f, -0.15f,   1.0f, 0.0f, // Bottom Right Vertex 1
        0.0f,  -0.2f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

        0.15f,  0.5f, -0.15f,   0.0f, 0.0f, // Top Right Vertex 0
        0.15f,  0.5f,  0.15f,   0.0f, 1.0f, // Bottom Right Vertex 1
        0.0f,  -0.2f,  0.0f,    0.5f, 1.0f, // Bottom Left Vertex 2

    };

    GLfloat boxCubeVerts[] = {

        //wooden box
        //verts               //normals
       -0.5f, -0.5f, -0.5f,   0.0f, 0.0f,
        0.5f, -0.5f, -0.5f,   0.0f, 0.0f,
        0.5f,  0.5f, -0.5f,   0.0f, 0.0f,
        0.5f,  0.5f, -0.5f,   0.0f, 0.0f,
       -0.5f,  0.5f, -0.5f,   0.0f, 0.0f,
       -0.5f, -0.5f, -0.5f,   0.0f, 0.0f,

       -0.5f, -0.5f,  0.5f,   1.0f, 0.0f,
        0.5f, -0.5f,  0.5f,   1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,   1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,   1.0f, 0.0f,
       -0.5f,  0.5f,  0.5f,   1.0f, 0.0f,
       -0.5f, -0.5f,  0.5f,   1.0f, 0.0f,

       -0.5f,  0.5f,  0.5f,   1.0f, 1.0f,
       -0.5f,  0.5f, -0.5f,   1.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,   1.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,   1.0f, 1.0f,
       -0.5f, -0.5f,  0.5f,   1.0f, 1.0f,
       -0.5f,  0.5f,  0.5f,   1.0f, 1.0f,

        0.5f,  0.5f,  0.5f,   1.0f, 1.0f,
        0.5f,  0.5f, -0.5f,   1.0f, 1.0f,
        0.5f, -0.5f, -0.5f,   1.0f, 1.0f,
        0.5f, -0.5f, -0.5f,   1.0f, 1.0f,
        0.5f, -0.5f,  0.5f,   1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,   1.0f, 1.0f,

       -0.5f, -0.5f, -0.5f,   0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,   0.0f, 1.0f,
        0.5f, -0.5f,  0.5f,   0.0f, 1.0f,
        0.5f, -0.5f,  0.5f,   0.0f, 1.0f,
       -0.5f, -0.5f,  0.5f,   0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,   0.0f, 1.0f,

       -0.5f,  0.5f, -0.5f,   0.0f, 0.0f,
        0.5f,  0.5f, -0.5f,   0.0f, 0.0f,
        0.5f,  0.5f,  0.5f,   0.0f, 0.0f,
        0.5f,  0.5f,  0.5f,   0.0f, 0.0f,
       -0.5f,  0.5f,  0.5f,   0.0f, 0.0f,
       -0.5f,  0.5f, -0.5f,   0.0f, 0.0f

    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;

    //////////////////////////////////////candle holder main body pyramid.
    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerUV));

    //generate multiple VAO
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    //build VBO
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV);

    //build pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);

    //////////////////////////////////////////////table top plane
    mesh.nPlaneVertices = sizeof(planeVerts) / (sizeof(planeVerts[0]) * (floatsPerVertex + floatsPerUV));

    //generate multiple VAO
    glGenVertexArrays(1, &mesh.planeVAO);
    glBindVertexArray(mesh.planeVAO);


    //build VBO
    glGenBuffers(1, &mesh.planeVBO);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.planeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(planeVerts), planeVerts, GL_STATIC_DRAW);

    //build pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);

    //////////////////////////////////////////////candle top pyramid
    mesh.cndlCubeVertices = sizeof(cndlCubeVerts) / (sizeof(cndlCubeVerts[0]) * (floatsPerVertex + floatsPerUV));

    //generate multiple VAO
    glGenVertexArrays(1, &mesh.cndlCubeVAO);
    glBindVertexArray(mesh.cndlCubeVAO);


    //build VBO
    glGenBuffers(1, &mesh.cndlCubeVBO);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.cndlCubeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cndlCubeVerts), cndlCubeVerts, GL_STATIC_DRAW);

    //build pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);

    //////////////////////////////////////////////wooden box
    mesh.boxCubeVertices = sizeof(boxCubeVerts) / (sizeof(boxCubeVerts[0]) * (floatsPerVertex + floatsPerUV));

    //generate multiple VAO
    glGenVertexArrays(1, &mesh.boxCubeVAO);
    glBindVertexArray(mesh.boxCubeVAO);

    //build VBO
    glGenBuffers(1, &mesh.boxCubeVBO);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.boxCubeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(boxCubeVerts), boxCubeVerts, GL_STATIC_DRAW);

    //build pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);

 }


void UCreateTexturedMesh(GLMesh& mesh)
{
}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(1, &mesh.vbo);

    glDeleteVertexArrays(1, &mesh.planeVAO);
    glDeleteBuffers(1, &mesh.planeVBO);
}


//load texture
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        //texture wrapping
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        //texture filtering
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); //unbind textures

        return true;
    }

    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}


//start shader create
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    int success = 0;
    char infoLog[512];

    //create program object.
    programId = glCreateProgram();

    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    //compile shader and eror reporting
    glCompileShader(vertexShaderId);
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    //compile vertex shader and error reporting
    glCompileShader(fragmentShaderId);
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    //send shaders to program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    //user program shader
    glUseProgram(programId);

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}
